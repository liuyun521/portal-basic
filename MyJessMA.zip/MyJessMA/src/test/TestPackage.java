package test;

import java.util.Set;

import net.sf.ehcache.Cache;

import org.apache.tools.ant.filters.BaseParamFilterReader;
import org.springframework.web.context.ContextLoader;
import org.springframework.web.context.WebApplicationContext;

import org.jessma.util.PackageHelper;

@SuppressWarnings("unused")
public class TestPackage
{
	public static void main(String[] args) throws Exception
	{
		test1();
	}
	
	private static void test1() throws Exception
	{
		Set<String> files = PackageHelper.getResourceNames("", true, new PackageHelper.FileTypesFilter("*.xml", "xml", ".dtd", "xsd"));
		
		System.out.println(files.size());
		System.out.println(files);
	}
	
	private static void test2() throws Exception
	{
		Set<Class<?>> classes = PackageHelper.getClasses("org.apache.tools.ant.filters", true, BaseParamFilterReader.class);
		
		System.out.println(classes.size());
		System.out.println(classes);
	}
}
