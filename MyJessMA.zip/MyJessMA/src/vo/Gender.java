package vo;

public class Gender extends SimpleVO
{
	public Gender()
	{
		super();
	}
	
	public Gender(int id, String name)
	{
		super(id, name);
	}
}
