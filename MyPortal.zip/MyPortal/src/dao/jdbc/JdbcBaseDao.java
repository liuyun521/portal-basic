package dao.jdbc;

import global.MyConfigParser;

import com.bruce.dao.jdbc.AbstractJdbcSessionMgr;
import com.bruce.dao.jdbc.JdbcFacade;

public class JdbcBaseDao extends JdbcFacade
{
	protected JdbcBaseDao()
	{
		this(MyConfigParser.getJdbcSessionMgr());
	}
	
	protected JdbcBaseDao(AbstractJdbcSessionMgr mgr)
	{
		super(mgr);
	}
}
