package dao.mybatis;

import com.bruce.dao.mybatis.MyBatisFacade;
import com.bruce.dao.mybatis.MyBatisSessionMgr;

import global.MyConfigParser;

public class MyBatisBaseDao extends MyBatisFacade
{
	protected MyBatisBaseDao()
	{
		this(MyConfigParser.getMyBaitsSessionMgr());
	}
	
	protected MyBatisBaseDao(MyBatisSessionMgr mgr)
	{
		super(mgr);
	}

}
